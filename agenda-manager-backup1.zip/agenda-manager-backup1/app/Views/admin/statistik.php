<?= $this->extend('admin/layouts/template') ?>

<?= $this->section('content') ?>
<div class="d-flex">
    <!-- Sidebar -->
    <div class="side-bar bg-dark text-white vh-100 p-3">
        <div class="text-center mb-4">
            <img src="/assets/img/ci4/icn.png" alt="Klinik Merdeka" class="img-fluid" style="max-width: 100px;">
        </div>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/admin/dashboard" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/statistik" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-chart-bar me-2"></i> Statistik
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/agenda" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-database me-2"></i> Data Antrian
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/profile" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-envelope me-2"></i> Email User
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/auth/logout" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Statistik Pelayanan -->
    <div class="container-xl mt-4">
        <h3>Statistik Pelayanan Harian</h3>

        <!-- Ringkasan Data -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Ringkasan Statistik</h5>
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Tanggal</th>
                            <th>Jenis Pelayanan</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dailyStats as $date => $services): ?>
                            <?php foreach ($services as $service => $count): ?>
                                <tr>
                                    <td><?= $date ?></td>
                                    <td><?= $service ?></td>
                                    <td><?= $count ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Grafik Statistik -->
        <div class="card">
            <div class="card-body">
                <canvas id="chartDailyStats"></canvas>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const stats = <?= json_encode($dailyStats) ?>;

    // Mendapatkan label (tanggal) dan dataset (jumlah layanan per jenis pelayanan)
    const labels = Object.keys(stats);
    const datasets = [];

    const pelayananTypes = [...new Set(Object.values(stats).flatMap(day => Object.keys(day)))];
    pelayananTypes.forEach(type => {
        datasets.push({
            label: type,
            data: labels.map(label => stats[label][type] || 0),
            backgroundColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.5)`,
            borderColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 1)`,
            borderWidth: 1
        });
    });

    const ctx = document.getElementById('chartDailyStats').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: 'Jumlah Pelayanan Harian'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?= $this->endSection() ?>