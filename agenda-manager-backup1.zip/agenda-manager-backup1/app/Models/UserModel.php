<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table      = 'users';         // Nama tabel di database
    protected $primaryKey = 'id';            // Primary key tabel

    // Kolom yang boleh diisi secara massal
    protected $allowedFields = ['username', 'password', 'role', 'created_at', 'updated_at'];

    // Aktifkan fitur timestamps
    protected $useTimestamps = true;         // Otomatis mengisi created_at & updated_at
    protected $createdField  = 'created_at'; // Nama kolom untuk created_at
    protected $updatedField  = 'updated_at'; // Nama kolom untuk updated_at

    // Aktifkan fitur soft delete (opsional)
    protected $useSoftDeletes = true;        // Aktifkan soft deletes
    protected $deletedField   = 'deleted_at'; // Nama kolom untuk soft delete

    /**
     * Mendapatkan pengguna berdasarkan username
     * 
     * @param string $username
     * @return array|null
     */
    public function getUserByUsername(string $username)
    {
        return $this->where('username', $username)->first();
    }

    /**
     * Hash password sebelum disimpan
     * 
     * @param string $password
     * @return string
     */
    public function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_DEFAULT);
    }

    /**
     * Verifikasi password pengguna
     * 
     * @param string $inputPassword
     * @param string $hashedPassword
     * @return bool
     */
    public function verifyPassword(string $inputPassword, string $hashedPassword): bool
    {
        return password_verify($inputPassword, $hashedPassword);
    }

    /**
     * Mendapatkan pengguna berdasarkan role
     * 
     * @param string $role
     * @return array
     */
    public function getUsersByRole(string $role): array
    {
        return $this->where('role', $role)->findAll();
    }

    /**
     * Autentikasi pengguna berdasarkan username dan password
     * 
     * @param string $username
     * @param string $password
     * @return array|null
     */
    public function authenticate(string $username, string $password)
    {
        $user = $this->getUserByUsername($username);

        if ($user && $this->verifyPassword($password, $user['password'])) {
            return $user;
        }

        return null;
    }

    /**
     * Update data pengguna berdasarkan ID
     * 
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function updateUserById(int $id, array $data): bool
    {
        return $this->update($id, $data);
    }
}
