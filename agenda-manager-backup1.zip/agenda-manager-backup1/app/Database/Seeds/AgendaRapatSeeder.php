<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AgendaRapatSeeder extends Seeder
{
    public function run()
    {
        $agendaModel = new \App\Models\AgendaRapatModel();

        $jenisRapat = [
            'Antrian Rawat Jalan Umum',
            'Antrian Poli Spesialis',
            'Antrian Gawat Darurat',
            'Antrian Laboratorium'
        ];

        $data = [];

        // Generate 30 data rapat dengan tanggal yang berbeda-beda
        for ($i = 0; $i < 30; $i++) {
            $month = ($i % 12) + 1; // Bulan 1-12
            $year = 2023; // Ganti tahun sesuai kebutuhan

            // Tanggal rapat acak dalam bulan
            $tanggalRapat = sprintf('%04d-%02d-%02d', $year, $month, rand(1, 28));

            // Menyusun data untuk 30 rapat
            $data[] = [
                'nama_pasien'   => 'Rapat ' . $jenisRapat[array_rand($jenisRapat)],
                'jenis_pelayanan'   => $jenisRapat[array_rand($jenisRapat)],
                'tanggal_kunjungan' => $tanggalRapat,
                'jam_kunjungan'     => sprintf('%02d:%02d:%02d', rand(8, 15), rand(0, 59), rand(0, 59)), // Jam acak
                'ruangan'  => 'Lokasi ' . rand(1, 10),
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ];
        }

        // Insert data ke dalam tabel agenda_rapat
        $agendaModel->insertBatch($data);
    }
}
