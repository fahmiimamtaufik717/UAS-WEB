<?= $this->extend('admin/layouts/template') ?>

<?= $this->section('content') ?>
<div class="d-flex">
    <!-- Sidebar -->
    <div class="side-bar bg-dark text-white vh-100 p-3">
        <div class="text-center mb-4">
            <img src="/assets/img/ci4/icn.png" alt="Klinik Merdeka" class="img-fluid" style="max-width: 100px;">
        </div>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/admin/dashboard" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/statistik" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-chart-bar me-2"></i> Statistik
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/agenda" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-database me-2"></i> Data Antrian
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/profile" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-envelope me-2"></i> Email User
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/auth/logout" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    
<div class="container-xl mt-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Form Edit Agenda</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="/admin/update/<?= esc($agenda['id']) ?>">
                        <?= csrf_field() ?>

                        <!-- Input Nama Pasien -->
                        <div class="mb-3">
                            <label for="nama_pasien" class="form-label">Nama Pasien</label>
                            <input type="text" 
                                   class="form-control <?= session('errors.nama_pasien') ? 'is-invalid' : '' ?>" 
                                   id="nama_pasien" 
                                   name="nama_pasien" 
                                   value="<?= old('nama_pasien', esc($agenda['nama_pasien'])) ?>" 
                                   required>
                            <?php if (session('errors.nama_pasien')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.nama_pasien') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Input Jenis Pelayanan -->
                        <div class="mb-3">
                            <label for="jenis_pelayanan" class="form-label">Jenis Pelayanan</label>
                            <select class="form-select <?= session('errors.jenis_pelayanan') ? 'is-invalid' : '' ?>" 
                                    id="jenis_pelayanan" 
                                    name="jenis_pelayanan" 
                                    required>
                                <option value="Antrian Rawat Jalan Umum" <?= old('jenis_pelayanan', $agenda['jenis_pelayanan']) === 'Antrian Rawat Jalan Umum' ? 'selected' : '' ?>>
                                    Antrian Rawat Jalan Umum
                                </option>
                                <option value="Antrian Poli Spesialis" <?= old('jenis_pelayanan', $agenda['jenis_pelayanan']) === 'Antrian Poli Spesialis' ? 'selected' : '' ?>>
                                    Antrian Poli Spesialis
                                </option>
                                <option value="Antrian Gawat Darurat" <?= old('jenis_pelayanan', $agenda['jenis_pelayanan']) === 'Antrian Gawat Darurat' ? 'selected' : '' ?>>
                                    Antrian Gawat Darurat
                                </option>
                                <option value="Antrian Laboratorium" <?= old('jenis_pelayanan', $agenda['jenis_pelayanan']) === 'Antrian Laboratorium' ? 'selected' : '' ?>>
                                    Antrian Laboratorium
                                </option>
                            </select>
                            <?php if (session('errors.jenis_pelayanan')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.jenis_pelayanan') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Input Tanggal Kunjungan -->
                        <div class="mb-3">
                            <label for="tanggal_kunjungan" class="form-label">Tanggal Kunjungan</label>
                            <input type="date" 
                                   class="form-control <?= session('errors.tanggal_kunjungan') ? 'is-invalid' : '' ?>" 
                                   id="tanggal_kunjungan" 
                                   name="tanggal_kunjungan" 
                                   value="<?= old('tanggal_kunjungan', esc($agenda['tanggal_kunjungan'])) ?>" 
                                   required>
                            <?php if (session('errors.tanggal_kunjungan')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.tanggal_kunjungan') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Input Jam Kunjungan -->
                        <div class="mb-3">
                            <label for="jam_kunjungan" class="form-label">Jam Kunjungan</label>
                            <input type="time" 
                                   class="form-control <?= session('errors.jam_kunjungan') ? 'is-invalid' : '' ?>" 
                                   id="jam_kunjungan" 
                                   name="jam_kunjungan" 
                                   value="<?= old('jam_kunjungan', esc($agenda['jam_kunjungan'])) ?>" 
                                   required>
                            <?php if (session('errors.jam_kunjungan')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.jam_kunjungan') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Input Ruangan -->
                        <div class="mb-3">
                            <label for="ruangan" class="form-label">Ruangan</label>
                            <input type="text" 
                                   class="form-control <?= session('errors.ruangan') ? 'is-invalid' : '' ?>" 
                                   id="ruangan" 
                                   name="ruangan" 
                                   value="<?= old('ruangan', esc($agenda['ruangan'])) ?>" 
                                   required>
                            <?php if (session('errors.ruangan')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.ruangan') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Tombol Aksi -->
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="/admin/agenda" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
