<?= $this->extend('user/layouts/template') ?>

<?= $this->section('content') ?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="side-bar bg-dark text-white vh-100 p-3">
        <div class="text-center mb-4">
            <img src="/assets/img/ci4/icn.png" alt="Klinik Merdeka" class="img-fluid" style="max-width: 100px;">
        </div>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/user/dashboard" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/user/agenda" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-database me-2"></i> Data Antrian
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/auth/logout" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Konten Utama -->
    <div class="container-xl mt-4 ms-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Form Tambah Antrian</h3>
                    </div>
                    <div class="card-body">
                        <form method="post" action="/user/store">
                            <?= csrf_field() ?>

                            <div class="mb-3">
                                <label for="nama_pasien" class="form-label">Nama Pasien</label>
                                <input type="text" class="form-control <?= isset($errors['nama_pasien']) ? 'is-invalid' : '' ?>" 
                                       id="nama_pasien" 
                                       name="nama_pasien" 
                                       value="<?= old('nama_pasien') ?>" 
                                       required>
                                <?php if (isset($errors['nama_pasien'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['nama_pasien'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="jenis_pelayanan" class="form-label">Jenis Pelayanan</label>
                                <select class="form-select <?= isset($errors['jenis_pelayanan']) ? 'is-invalid' : '' ?>" 
                                        id="jenis_pelayanan" 
                                        name="jenis_pelayanan" 
                                        required>
                                    <option value="">Pilih Jenis Pelayanan</option>
                                    <option value="Antrian Rawat Jalan Umum" <?= old('jenis_pelayanan') == 'Antrian Rawat Jalan Umum' ? 'selected' : '' ?>>Antrian Rawat Jalan Umum</option>
                                    <option value="Antrian Poli Spesialis" <?= old('jenis_pelayanan') == 'Antrian Poli Spesialis' ? 'selected' : '' ?>>Antrian Poli Spesialis</option>
                                    <option value="Antrian Rawat Darurat" <?= old('jenis_pelayanan') == 'Antrian Rawat Darurat' ? 'selected' : '' ?>>Antrian Rawat Darurat</option>
                                    <option value="Antrian Laboratorium" <?= old('jenis_pelayanan') == 'Antrian Laboratorium' ? 'selected' : '' ?>>Antrian Laboratorium</option>
                                </select>
                                <?php if (isset($errors['jenis_pelayanan'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['jenis_pelayanan'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="tanggal_kunjungan" class="form-label">Tanggal Kunjungan</label>
                                <input type="date" class="form-control <?= isset($errors['tanggal_kunjungan']) ? 'is-invalid' : '' ?>" 
                                       id="tanggal_kunjungan" 
                                       name="tanggal_kunjungan" 
                                       value="<?= old('tanggal_kunjungan') ?>" 
                                       required>
                                <?php if (isset($errors['tanggal_kunjungan'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['tanggal_kunjungan'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="jam_kunjungan" class="form-label">Jam Kunjungan</label>
                                <input type="time" class="form-control <?= isset($errors['jam_kunjungan']) ? 'is-invalid' : '' ?>" 
                                       id="jam_kunjungan" 
                                       name="jam_kunjungan" 
                                       value="<?= old('jam_kunjungan') ?>" 
                                       required>
                                <?php if (isset($errors['jam_kunjungan'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['jam_kunjungan'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="ruangan" class="form-label">Ruangan</label>
                                <input type="text" class="form-control <?= isset($errors['ruangan']) ? 'is-invalid' : '' ?>" 
                                       id="ruangan" 
                                       name="ruangan" 
                                       value="<?= old('ruangan') ?>" 
                                       required>
                                <?php if (isset($errors['ruangan'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['ruangan'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="/user/agenda" class="btn btn-secondary">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
