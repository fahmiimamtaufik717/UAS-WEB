<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Auth Routes
$routes->get('/', 'Home::index');
$routes->get('/auth/login', 'Auth::login');
$routes->get('auth/kontak', 'AuthController::kontak');
$routes->post('kontak/send', 'AuthController::sendKontak');
$routes->post('/auth/loginAttempt', 'Auth::loginAttempt');
$routes->get('/auth/logout', 'Auth::logout');
$routes->get('/auth/register', 'Auth::register');
$routes->post('/auth/registerUser', 'Auth::registerUser');

// Admin Routes
$routes->get('/admin/dashboard', 'AdminController::dashboard');
$routes->get('/admin/agenda', 'AdminController::index');
$routes->get('/admin/email_user', 'AdminController::email_user');
$routes->get('/admin/statistik', 'AdminController::statistik');
$routes->get('/admin/create', 'AdminController::create');
$routes->post('/admin/store', 'AdminController::store');
$routes->get('/admin/edit/(:num)', 'AdminController::edit/$1');
$routes->post('/admin/update/(:num)', 'AdminController::update/$1');
$routes->delete('/admin/delete/(:num)', 'AdminController::delete/$1');
$routes->get('/admin/approve/(:num)', 'AdminController::approve/$1');
$routes->get('/admin/reject/(:num)', 'AdminController::reject/$1');

// User Routes
$routes->get('/user/dashboard', 'UserController::dashboard');
$routes->get('/user/agenda', 'UserController::index');
$routes->get('/user/statistik', 'UserController::statistik');
$routes->get('/user/create', 'UserController::create');
$routes->post('/user/store', 'UserController::store');
$routes->get('/user/edit/(:num)', 'UserController::edit/$1');
$routes->post('/user/update/(:num)', 'UserController::update/$1');
$routes->delete('/user/delete/(:num)', 'UserController::delete/$1');

