<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengelolaan Antrian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }
        .navbar {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .hero-section {
            background: linear-gradient(135deg, #007bff, #6610f2);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 3rem;
            font-weight: 700;
        }
        .hero-section p {
            font-size: 1.2rem;
        }
        .feature-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-radius: 12px;
            overflow: hidden;
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        .feature-icon {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
        }
        #signup {
            background-color: #6610f2;
            color: white;
            padding: 40px 20px;
        }
        #signup .btn {
            background-color: white;
            color: #6610f2;
            font-weight: bold;
        }
        #signup .btn:hover {
            background-color: #fff3f7;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container-xl">
            <a class="navbar-brand fw-bold text-primary" href="#">Klinik Merdeka</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-black" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-black" href="#features">Data Poli</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-black" href="auth/kontak">Kontak</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-black px-3" href="auth/login">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section animate__animated animate__fadeIn">
        <div class="container-xl">
            <h1>Kelola Antrian Rawat Jalan dengan Mudah</h1>
            <p class="lead mt-3">Aplikasi pengelolaan antrian yang dirancang untuk mempermudah fasilitas kesehatan dalam mengatur dan memantau pasien.</p>
            <div class="mt-4">
                <a href="#features" class="btn btn-light btn-lg me-2">Pelajari Lebih Lanjut</a>
                <a href="auth/register" class="btn btn-outline-light btn-lg">Daftar Sekarang</a>
            </div>
        </div>
    </div>

    <!-- Features Section -->
    <div id="features" class="mt-5 container-xl">
        <h2 class="text-center fw-bold mb-4">Fitur Utama</h2>
        <div class="row text-center">
            <div class="col-lg-4 mb-4">
            <div class="card feature-card shadow-sm border-0 h-100 animate__animated animate__zoomIn animate__delay-1s">
                <div class="card-body">
                    <!-- Pastikan path menuju gambar benar -->
                    <img src="/assets/img/ci4/antrian.jpg" alt="icon" class="feature-icon img-fluid mb-3">
                    <h5 class="card-title fw-bold">Penjadwalan Mudah</h5>
                    <p class="card-text">Atur jadwal antrian dengan cepat dan efisien.</p>
                </div>
            </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card feature-card shadow-sm border-0 h-100 animate__animated animate__zoomIn animate__delay-2s">
                    <div class="card-body">
                        <img src="/assets/img/ci4/kolaborasi.jpg" alt="icon" class="feature-icon img-fluid mb-3">
                        <h5 class="card-title fw-bold">Kolaborasi Tim</h5>
                        <p class="card-text">Berkolaborasi dalam pengelolaan data pasien dan jadwal pelayanan.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card feature-card shadow-sm border-0 h-100 animate__animated animate__zoomIn animate__delay-3s">
                    <div class="card-body">
                        <img src="/assets/img/ci4/pelackan.png" alt="icon" class="feature-icon img-fluid mb-3">
                        <h5 class="card-title fw-bold">Pelacakan Efektif</h5>
                        <p class="card-text">Pantau hasil antrian dengan laporan yang dapat disesuaikan.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Signup Section -->
    <div id="signup" class="mt-5">
        <div class="container-xl text-center">
            <h2 class="fw-bold mb-4">Daftar Sekarang dan Permudah Pengelolaan Antrian Anda</h2>
            <p class="text-white">Jadilah bagian dari sistem pengelolaan modern untuk kemudahan pasien dan tim Anda.</p>
            <a href="auth/login" class="btn btn-lg">Mulai Sekarang</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
