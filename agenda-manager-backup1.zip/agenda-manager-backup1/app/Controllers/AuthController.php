<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class AuthController extends BaseController
{
    public function kontak()
    {
        // Tampilkan halaman kontak
        return view('auth/kontak');
    }

    public function sendKontak()
    {
        // Tangani data yang dikirimkan dari form
        $name = $this->request->getPost('name');
        $email = $this->request->getPost('email');
        $message = $this->request->getPost('message');

        // Validasi sederhana
        if (!$name || !$email || !$message) {
            return redirect()->back()->with('error', 'Semua kolom wajib diisi.');
        }

        // Simulasi tindakan, seperti menyimpan data ke database atau mengirim email
        // Contoh: save ke database (jika ada model)
        // $this->kontakModel->save([
        //     'name' => $name,
        //     'email' => $email,
        //     'message' => $message,
        // ]);

        // Beri pesan sukses ke pengguna
        return redirect()->to('/auth/kontak')->with('success', 'Pesan Anda berhasil dikirim. Terima kasih!');
    }
}
