<?= $this->extend('admin/layouts/template') ?>

<?= $this->section('content') ?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="side-bar bg-dark text-white vh-100 p-3">
        <div class="text-center mb-4">
            <img src="/assets/img/ci4/icn.png" alt="Klinik Merdeka" class="img-fluid" style="max-width: 100px;">
        </div>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/admin/dashboard" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/statistik" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-chart-bar me-2"></i> Statistik
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/agenda" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-database me-2"></i> Data Antrian
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/profile" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-envelope me-2"></i> Email User
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/auth/logout" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="container-fluid p-4" style="margin-left: 230px;">
        <!-- Header -->
        <div class="mb-4 d-flex justify-content-between">
            <a href="/admin/create" class="btn btn-primary">Tambah Antrian</a>
            <!-- Filter -->
            <form method="get" action="/admin/agenda" class="d-flex">
                <select name="status" class="form-select form-select-sm me-2">
                    <option value="" <?= $status === null || $status === '' ? 'selected' : '' ?>>Semua Status</option>
                    <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="approved" <?= $status === 'approved' ? 'selected' : '' ?>>Approved</option>
                    <option value="rejected" <?= $status === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>
                <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar Antrian</h3>
            </div>

            <!-- Search -->
            <div class="card-body border-bottom py-3">
                <div class="d-flex justify-content-end">
                    <form method="get" action="/admin/agenda" class="d-flex">
                        <input type="text" name="search" class="form-control form-control-sm me-2" placeholder="Cari Antrian" value="<?= esc($search) ?>">
                        <button type="submit" class="btn btn-sm btn-primary">Cari</button>
                    </form>
                </div>
            </div>

            <!-- Table Data -->
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Pasien</th>
                            <th>Jenis Pelayanan</th>
                            <th>Tanggal Kunjungan</th>
                            <th>Jam Kunjungan</th>
                            <th>Ruangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = (int) (isset($pager) ? $pager->getPerPage() * ($pager->getCurrentPage() - 1) : 0); ?>
                        <?php foreach ($agenda as $a): ?>
                            <tr>
                                <td><?= ++$no ?></td>
                                <td><?= $a['nama_pasien'] ?></td>
                                <td><?= $a['jenis_pelayanan'] ?></td>
                                <td><?= $a['tanggal_kunjungan'] ?></td>
                                <td><?= $a['jam_kunjungan'] ?></td>
                                <td><?= $a['ruangan'] ?></td>
                                <td>
                                    <?php if ($a['status'] === 'pending'): ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    <?php elseif ($a['status'] === 'approved'): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($a['status'] === 'pending'): ?>
                                        <a href="/admin/approve/<?= $a['id'] ?>" class="btn btn-success btn-sm">Approve</a>
                                        <a href="/admin/reject/<?= $a['id'] ?>" class="btn btn-danger btn-sm">Reject</a>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>Processed</button>
                                    <?php endif; ?>
                                    <a href="/admin/edit/<?= $a['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <button type="button" class="btn btn-danger btn-sm" onclick="openDeleteModal(<?= $a['id'] ?>)">Hapus</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="card-footer d-flex justify-content-between align-items-center">
                <p class="m-0 text-secondary">Showing <?= $pager->getCurrentPage() ?> of <?= $pager->getPageCount() ?> entries</p>
                <ul class="pagination m-0">
                    <?= $pager->links() ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Hapus -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus Antrian</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin menghapus antrian ini?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form id="deleteForm" method="post" style="display:inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Script -->
<script>
    function openDeleteModal(id) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = '/admin/delete/' + id;
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        deleteModal.show();
    }
</script>

<!-- Custom Styles -->
<style>
    body {
        background-color: #f8f9fa;
    }

    .side-bar {
        width: 230px;
        position: fixed;
    }

    .container-fluid {
        margin-left: 230px;
    }

    .card {
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .btn {
        border-radius: 5px;
    }
</style>

<?= $this->endSection() ?>
