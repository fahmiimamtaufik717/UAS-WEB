<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateAgendaRapatTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => [
                'type'           => 'INT',
                'constraint'     => 5,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'jenis_pelayanan'    => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'jenis_pelayanan'    => [
                'type'       => 'ENUM',
                'constraint' => ['Antrian Rawat Jalan Umum', 'Antrian Poli Spesialis', 'Antrian Gawat Darurat', 'Antrian Laboratorium'],
            ],
            'tanggal_kunjungan'  => [
                'type'       => 'DATE',
            ],
            'jam_kunjungan'      => [
                'type'       => 'TIME',
            ],
            'ruangan'   => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'created_at'     => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at'     => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('agenda_rapat');
    }

    public function down()
    {
        $this->forge->dropTable('agenda_rapat');
    }
}
