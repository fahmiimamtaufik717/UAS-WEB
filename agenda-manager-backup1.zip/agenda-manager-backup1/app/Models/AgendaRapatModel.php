<?php

namespace App\Models;

use CodeIgniter\Model;

class AgendaRapatModel extends Model
{
    protected $table = 'agenda_rapat';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'nama_pasien',
        'jenis_pelayanan',
        'tanggal_kunjungan',
        'jam_kunjungan',
        'ruangan',
        'status',
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Mendapatkan statistik harian berdasarkan tanggal dan jenis pelayanan.
     *
     * @return array
     */
    public function getDailyStats()
    {
        return $this->select('DATE(tanggal_kunjungan) as date, jenis_pelayanan, COUNT(*) as total')
                    ->where('status', 'approved') // Tambahkan kondisi untuk status 'approved'
                    ->groupBy('DATE(tanggal_kunjungan), jenis_pelayanan')
                    ->orderBy('DATE(tanggal_kunjungan)', 'asc')
                    ->findAll();
    }
    

    /**
     * Filter agenda berdasarkan status, pencarian, dan pagination.
     */
    public function getFilteredAgenda($status = null, $search = null, $perPage = 10)
    {
        $query = $this->select('*');

        if (!empty($status)) {
            $query->where('status', $status);
        }

        if (!empty($search)) {
            $query->like('nama_pasien', $search);
        }

        return $query->paginate($perPage);
    }

    /**
     * Statistik Rapat Bulanan.
     */
    public function getMonthlyStats()
    {
        return $this->select('YEAR(tanggal_kunjungan) AS year, MONTH(tanggal_kunjungan) AS month, COUNT(id) AS total')
            ->groupBy('year, month')
            ->orderBy('year, month')
            ->findAll();
    }

    /**
     * Statistik Rapat Mingguan.
     */
    public function getWeeklyStats()
    {
        return $this->select('YEAR(tanggal_kunjungan) AS year, WEEK(tanggal_kunjungan) AS week, jenis_pelayanan, COUNT(id) AS total')
            ->groupBy('year, week, jenis_pelayanan')
            ->orderBy('year, week')
            ->findAll();
    }

    /**
     * Menyetujui Agenda.
     */
    public function approveAgenda($id)
    {
        return $this->update($id, ['status' => 'approved']);
    }

    /**
     * Menolak Agenda.
     */
    public function rejectAgenda($id)
    {
        return $this->update($id, ['status' => 'rejected']);
    }

    /**
     * Menghapus Agenda.
     */
    public function deleteAgenda($id)
    {
        return $this->delete($id);
    }

    /**
     * Mendapatkan semua status unik dari tabel agenda untuk dropdown.
     */
    public function getStatusOptions()
    {
        return $this->select('DISTINCT(status)')->findAll();
    }
}
