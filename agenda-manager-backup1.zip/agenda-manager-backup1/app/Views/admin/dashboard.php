<?php $this->extend('admin/layouts/template'); ?>

<?php $this->section('content'); ?>
<div class="d-flex">
    <!-- Sidebar -->
    <div class="side-bar bg-dark text-white vh-100 p-3">
        <div class="text-center mb-4">
            <img src="/assets/img/ci4/icn.png" alt="Klinik Merdeka" class="img-fluid" style="max-width: 100px;">
        </div>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/admin/dashboard" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/statistik" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-chart-bar me-2"></i> Statistik
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/agenda" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-database me-2"></i> Data Antrian
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/admin/email_user" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-envelope me-2"></i> Email User
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/auth/logout" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="container-fluid p-4" style="margin-left: 230px;">
        <!-- Title -->
        <div class="text-center mb-4">
            <h2 class="fw-bold title-text">SISTEM INFORMASI ANTRIAN RAWAT JALAN KLINIK MERDEKA</h2>
            <p class="text-muted">Pilih salah satu kategori di bawah untuk melihat detail antrian sesuai kebutuhan anda.</p>
        </div>

        <!-- Grid Cards -->
        <div class="row g-4">
            <!-- Card Item 1 -->
            <div class="col-md-3">
                <div class="card shadow-sm text-center py-4 hover-effect">
                    <i class="fas fa-user-injured fa-2x text-primary mb-3"></i>
                    <h5 class="fw-bold">Antrian Rawat Jalan Umum</h5>
                    <p class="text-muted">Untuk pasien dengan kebutuhan layanan kesehatan dasar.</p>
                </div>
            </div>

            <!-- Card Item 2 -->
            <div class="col-md-3">
                <div class="card shadow-sm text-center py-4 hover-effect">
                    <i class="fas fa-stethoscope fa-2x text-success mb-3"></i>
                    <h5 class="fw-bold">Antrian Poli Spesialis</h5>
                    <p class="text-muted">Untuk konsultasi dengan dokter spesialis.</p>
                </div>
            </div>

            <!-- Card Item 3 -->
            <div class="col-md-3">
                <div class="card shadow-sm text-center py-4 hover-effect">
                    <i class="fas fa-ambulance fa-2x text-danger mb-3"></i>
                    <h5 class="fw-bold">Antrian Rawat Darurat</h5>
                    <p class="text-muted">Untuk kondisi kesehatan yang membutuhkan penanganan darurat.</p>
                </div>
            </div>

            <!-- Card Item 4 -->
            <div class="col-md-3">
                <div class="card shadow-sm text-center py-4 hover-effect">
                    <i class="fas fa-vials fa-2x text-warning mb-3"></i>
                    <h5 class="fw-bold">Antrian Laboratorium</h5>
                    <p class="text-muted">Untuk pemeriksaan laboratorium seperti tes darah.</p>
                </div>
            </div>
        </div>

        <!-- Detailed Statistics -->
        <div class="row mt-5">
            <div class="col-md-12">
                <div class="card shadow-lg p-4">
                    <h5 class="fw-bold mb-3">Detail Informasi Antrian</h5>
                    <div class="row text-center">
                        <div class="col-md-3">
                            <h6 class="fw-bold">Rawat Jalan Umum</h6>
                            <p>Untuk pasien dengan kebutuhan layanan kesehatan dasar.</p>
                            <img src="/assets/img/ci4/umum.jpg" alt="Rawat Jalan Umum" class="img-fluid mt-2" style="max-width: 100px;">
                        </div>
                        <div class="col-md-3">
                            <h6 class="fw-bold">Poli Spesialis</h6>
                            <p>Untuk konsultasi dengan dokter spesialis.</p>
                            <img src="/assets/img/ci4/spesialis.png" alt="Poli Spesialis" class="img-fluid mt-2" style="max-width: 100px;">
                        </div>
                        <div class="col-md-3">
                            <h6 class="fw-bold">Rawat Darurat</h6>
                            <p>Untuk kondisi kesehatan yang membutuhkan penanganan darurat.</p>
                            <img src="/assets/img/ci4/darurat1.png" alt="Rawat Darurat" class="img-fluid mt-2" style="max-width: 100px;">
                        </div>
                        <div class="col-md-3">
                            <h6 class="fw-bold">Laboratorium</h6>
                            <p>Untuk pemeriksaan laboratorium seperti tes darah.</p>
                            <img src="/assets/img/ci4/tes.png" alt="Laboratorium" class="img-fluid mt-2" style="max-width: 100px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Custom Styles -->
<style>
    body {
        background-color: #f9f9f9;
        font-family: 'Roboto', sans-serif;
    }

    .side-bar {
        width: 230px;
        position: fixed;
    }

    .card {
        border-radius: 15px;
        transition: all 0.3s ease-in-out;
        background-color: #ffffff;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
    }

    .hover-effect {
        cursor: pointer;
    }

    .title-text {
        color: #343a40;
    }

    .text-muted {
        font-size: 0.9rem;
    }

    .fa-2x {
        display: block;
    }
</style>

<?php $this->endSection(); ?>
