<?php

namespace App\Controllers;

use App\Models\AgendaRapatModel;
use CodeIgniter\Controller;

class UserController extends Controller
{
    protected $agendaModel;

    public function __construct()
    {
        // Load helper untuk URL dan form
        helper(['url', 'form']);

        // Inisialisasi model
        $this->agendaModel = new AgendaRapatModel();
    }

    /**
     * Middleware-like: Periksa autentikasi dan role
     */
    private function checkAuth()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'user') {
            return redirect()->to('/auth/login')->send();
        }
    }

    /**
     * Dashboard User
     */
    public function dashboard()
    {
        $this->checkAuth();
        return view('user/dashboard');
    }

    /**
     * Daftar Agenda
     */
    public function index()
    {
        $this->checkAuth();

        // Ambil data filter pencarian dan jumlah entri per halaman
        $search = $this->request->getVar('search') ?? '';
        $entriesPerPage = $this->request->getVar('entriesPerPage') ?? 8;

        // Data untuk tabel agenda
        $data = [
            'agenda' => $this->agendaModel
                ->like('nama_pasien', $search)
                ->paginate($entriesPerPage),
            'pager'  => $this->agendaModel->pager,
            'search' => $search,
        ];

        return view('user/agenda', $data);
    }

    /**
     * Form Tambah Data
     */
    public function create()
    {
        $this->checkAuth();
        return view('user/create', [
            'validation' => \Config\Services::validation(),
        ]);
    }

    /**
     * Proses Tambah Data
     */
    public function store()
    {
        $this->checkAuth();

        // Aturan validasi
        $validationRules = [
            'nama_pasien'      => 'required|min_length[3]|max_length[100]',
            'jenis_pelayanan'  => 'required',
            'tanggal_kunjungan' => 'required|valid_date[Y-m-d]',
            'jam_kunjungan'    => 'required|valid_date[H:i]',
            'ruangan'          => 'required|min_length[1]|max_length[50]',
        ];

        // Validasi input
        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // Simpan data ke database
        $this->agendaModel->save([
            'nama_pasien'      => $this->request->getPost('nama_pasien'),
            'jenis_pelayanan'  => $this->request->getPost('jenis_pelayanan'),
            'tanggal_kunjungan' => $this->request->getPost('tanggal_kunjungan'),
            'jam_kunjungan'    => $this->request->getPost('jam_kunjungan'),
            'ruangan'          => $this->request->getPost('ruangan'),
            'status'           => 'pending', // Status default
        ]);

        return redirect()->to('/user/agenda')->with('success', 'Data berhasil ditambahkan.');
    }

    /**
     * Form Edit Data
     */
    public function edit($id)
    {
        $this->checkAuth();

        $agenda = $this->agendaModel->find($id);

        if (!$agenda) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data tidak ditemukan.");
        }

        return view('user/edit', [
            'agenda'     => $agenda,
            'validation' => \Config\Services::validation(),
        ]);
    }

    /**
     * Proses Edit Data
     */
    public function update($id)
    {
        $this->checkAuth();

        // Aturan validasi
        $validationRules = [
            'nama_pasien'      => 'required|min_length[3]|max_length[100]',
            'jenis_pelayanan'  => 'required',
            'tanggal_kunjungan' => 'required|valid_date[Y-m-d]',
            'jam_kunjungan'    => 'required|valid_date[H:i]',
            'ruangan'          => 'required|min_length[1]|max_length[50]',
        ];

        // Validasi input
        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // Update data di database
        $this->agendaModel->update($id, [
            'nama_pasien'      => $this->request->getPost('nama_pasien'),
            'jenis_pelayanan'  => $this->request->getPost('jenis_pelayanan'),
            'tanggal_kunjungan' => $this->request->getPost('tanggal_kunjungan'),
            'jam_kunjungan'    => $this->request->getPost('jam_kunjungan'),
            'ruangan'          => $this->request->getPost('ruangan'),
        ]);

        return redirect()->to('/user/agenda')->with('success', 'Data berhasil diperbarui.');
    }

    /**
     * Hapus Data
     */
    public function delete($id)
    {
        $this->checkAuth();

        $agenda = $this->agendaModel->find($id);

        if (!$agenda) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data tidak ditemukan.");
        }

        $this->agendaModel->delete($id);

        return redirect()->to('/user/agenda')->with('success', 'Data berhasil dihapus.');
    }
}
