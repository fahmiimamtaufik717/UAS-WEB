<?php

namespace App\Controllers;

use App\Models\AgendaRapatModel;
use CodeIgniter\Controller;

class AdminController extends Controller
{
    protected $agendaModel;

    public function __construct()
    {
        helper(['url', 'form', 'session']);
        $this->agendaModel = new AgendaRapatModel();
    }

    /**
     * Dashboard Admin
     */
    public function dashboard()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        return view('admin/dashboard');
    }

    /**
     * Daftar Agenda
     */
    public function index()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        // Ambil parameter filter
        $search = $this->request->getVar('search') ?? '';
        $entriesPerPage = $this->request->getVar('entriesPerPage') ?? 8;
        $status = $this->request->getGet('status') ?? '';

        // Query data dengan filter
        $agendaQuery = $this->agendaModel;

        if (!empty($search)) {
            $agendaQuery = $agendaQuery->like('nama_pasien', $search);
        }

        if (!empty($status) && $status !== 'semua') {
            $agendaQuery = $agendaQuery->where('status', $status);
        }

        $data = [
            'agenda' => $agendaQuery->paginate($entriesPerPage),
            'pager'  => $this->agendaModel->pager,
            'search' => $search,
            'status' => $status,
        ];

        return view('admin/agenda', $data);
    }

    /**
     * Halaman Statistik Agenda
     */
    public function statistik()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }
    
        // Ambil data statistik harian dari model
        $stats = $this->agendaModel->getDailyStats();
    
        // Format data agar siap digunakan di view
        $formattedStats = [];
        foreach ($stats as $stat) {
            $date = $stat['date'];
            $formattedStats[$date][$stat['jenis_pelayanan']] = $stat['total'];
        }
    
        $data = [
            'dailyStats' => $formattedStats,
        ];
    
        return view('admin/statistik', $data);
    }
    

    /**
     * Menghapus Data Agenda
     */
    public function delete($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        // Cek apakah ID valid
        if (!$this->agendaModel->find($id)) {
            return redirect()->to('/admin/agenda')->with('error', 'Data tidak ditemukan.');
        }

        // Hapus data
        $this->agendaModel->delete($id);

        return redirect()->to('/admin/agenda')->with('success', 'Data berhasil dihapus.');
    }

    /**
     * Menampilkan Form Tambah Data Agenda
     */
    public function create()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        return view('admin/create_agenda');
    }

    /**
     * Menyimpan Data Baru Agenda (Default Status: Pending)
     */
    public function store()
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        // Validasi input
        $rules = [
            'nama_pasien'      => 'required|min_length[3]',
            'jenis_pelayanan'  => 'required',
            'tanggal_kunjungan' => 'required|valid_date',
            'jam_kunjungan'    => 'required',
            'ruangan'          => 'required',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Simpan data baru dengan status pending
        $data = [
            'nama_pasien'      => $this->request->getPost('nama_pasien'),
            'jenis_pelayanan'  => $this->request->getPost('jenis_pelayanan'),
            'tanggal_kunjungan' => $this->request->getPost('tanggal_kunjungan'),
            'jam_kunjungan'    => $this->request->getPost('jam_kunjungan'),
            'ruangan'          => $this->request->getPost('ruangan'),
            'status'           => 'pending',
        ];

        $this->agendaModel->insert($data);

        return redirect()->to('/admin/agenda')->with('success', 'Data berhasil ditambahkan dan menunggu persetujuan.');
    }

    /**
     * Menampilkan Form Edit Data Agenda
     */
    public function edit($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        $agenda = $this->agendaModel->find($id);

        if (!$agenda) {
            return redirect()->to('/admin/agenda')->with('error', 'Data tidak ditemukan.');
        }

        $data = ['agenda' => $agenda];
        return view('admin/edit', $data);
    }

    /**
     * Mengupdate Data Agenda
     */
    public function update($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        // Validasi input
        $rules = [
            'nama_pasien'      => 'required|min_length[3]',
            'jenis_pelayanan'  => 'required',
            'tanggal_kunjungan' => 'required|valid_date',
            'jam_kunjungan'    => 'required',
            'ruangan'          => 'required',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Perbarui data
        $data = [
            'nama_pasien'      => $this->request->getPost('nama_pasien'),
            'jenis_pelayanan'  => $this->request->getPost('jenis_pelayanan'),
            'tanggal_kunjungan' => $this->request->getPost('tanggal_kunjungan'),
            'jam_kunjungan'    => $this->request->getPost('jam_kunjungan'),
            'ruangan'          => $this->request->getPost('ruangan'),
        ];

        $this->agendaModel->update($id, $data);

        return redirect()->to('/admin/agenda')->with('success', 'Data berhasil diperbarui.');
    }

    /**
     * Menyetujui Data Agenda
     */
    public function approve($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        if (!$this->agendaModel->find($id)) {
            return redirect()->to('/admin/agenda')->with('error', 'Data tidak ditemukan.');
        }

        $this->agendaModel->update($id, ['status' => 'approved']);

        return redirect()->to('/admin/agenda')->with('success', 'Antrian berhasil disetujui.');
    }

    /**
     * Menolak Data Agenda
     */
    public function reject($id)
    {
        if (!$this->isAdmin()) {
            return redirect()->to('/login');
        }

        if (!$this->agendaModel->find($id)) {
            return redirect()->to('/admin/agenda')->with('error', 'Data tidak ditemukan.');
        }

        $this->agendaModel->update($id, ['status' => 'rejected']);

        return redirect()->to('/admin/agenda')->with('error', 'Antrian telah ditolak.');
    }

    /**
     * Fungsi Helper: Periksa apakah user adalah admin
     */
    private function isAdmin()
    {
        return session()->get('isLoggedIn') && session()->get('role') === 'admin';
    }
}
