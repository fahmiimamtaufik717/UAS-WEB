<?= $this->extend('auth/layouts/template') ?>

<?= $this->section('content') ?>
<div style="min-height: 100vh; background: linear-gradient(to bottom, #6a11cb, #2575fc); display: flex; flex-direction: column;">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow">
        <div class="container-xl">
            <a class="navbar-brand fw-bold text-primary" href="#">Klinik Merdeka</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link text-black" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black" href="#features">Data Poli</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black" href="/auth/kontak">Kontak</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-white px-3" href="/auth/login">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Kontak Section -->
    <div class="container my-5 pt-5">
        <div class="row">
            <!-- Form Kontak -->
            <div class="col-md-6">
                <div class="contact-form bg-white p-4 shadow rounded">
                    <h5 class="mb-4">Kontak</h5>
                    <p>Hubungi kami jika ada pertanyaan atau masalah.</p>
                    <form action="/kontak/send" method="POST">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Lengkap</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="Nama Lengkap" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email (Wajib)</label>
                            <input type="email" id="email" name="email" class="form-control" placeholder="Email" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Tulis Pesan</label>
                            <textarea id="message" name="message" class="form-control" rows="5" placeholder="Tulis pesan Anda" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Kirim</button>
                    </form>
                </div>
            </div>

            <!-- Peta -->
            <div class="col-md-6">
                <div class="map-container shadow rounded overflow-hidden">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31691.372290707835!2d108.2303001245626!3d-6.832160594601071!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6e28bb294c8a43%3A0xb8cf491a74ef13f0!2sRSUD%20Majalengka!5e0!3m2!1sid!2sid!4v1697808241943!5m2!1sid!2sid" 
                        width="100%" 
                        height="400" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Custom Styles -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
    }

    .container {
        margin-top: 100px; /* Menambah jarak dari header */
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
        padding: 10px;
        font-size: 16px;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    input.form-control,
    textarea.form-control {
        border-radius: 5px;
        padding: 10px;
        font-size: 14px;
    }

    .text-muted a {
        color: #6c757d;
        text-decoration: none;
        transition: color 0.3s;
    }

    .text-muted a:hover {
        color: #0056b3;
    }
</style>

<?= $this->endSection() ?>
