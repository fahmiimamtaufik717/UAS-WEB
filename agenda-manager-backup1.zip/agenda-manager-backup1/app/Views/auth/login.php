<?= $this->extend('auth/layouts/template') ?>

<?= $this->section('content') ?>
<div style="min-height: 100vh; background: linear-gradient(to bottom, #6a11cb, #2575fc); display: flex; flex-direction: column;">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow">
        <div class="container-xl">
            <a class="navbar-brand fw-bold text-primary" href="#">Klinik Merdeka</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link text-black" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black" href="#features">Data Poli</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-black" href="/auth/kontak">Kontak</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-white px-3" href="/auth/login">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Login Form -->
    <div class="page-center" style="flex: 1; display: flex; align-items: center; justify-content: center; padding-top: 70px;">
        <div class="container text-center">
            <div class="login-box shadow p-4 bg-white rounded">
                <h2 class="mb-3">Login</h2>
                <p class="text-muted mb-4">Masukkan username dan password untuk melanjutkan</p>

                <!-- Display Success and Error Messages -->
                <?php if (session()->get('message')): ?>
                    <div class="alert alert-success"><?= session()->get('message') ?></div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                <?php endif; ?>

                <form action="/auth/loginAttempt" method="post">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <input type="text" id="username" name="username" class="form-control" placeholder="Username" required>
                    </div>
                    <div class="mb-3">
                        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>

                <div class="mt-3">
                    <p class="text-muted">Belum punya akun? <a href="/auth/register">Daftar Sekarang</a></p>
                    <a href="/auth/forgot" class="text-muted">Lupa password?</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
    }
    .page-center {
        padding-top: 60px;
    }
    .login-box {
        max-width: 400px;
        margin: 0 auto;
        background-color: #fff;
        border-radius: 10px;
    }
    .btn-primary {
        background-color: #007bff;
        border: none;
        padding: 10px;
        font-size: 16px;
        border-radius: 5px;
        transition: background-color 0.3s;
    }
    .btn-primary:hover {
        background-color: #0056b3;
    }
    input.form-control {
        border-radius: 5px;
        padding: 10px;
        font-size: 14px;
    }
    .text-muted a {
        color: #6c757d;
        text-decoration: none;
        transition: color 0.3s;
    }
    .text-muted a:hover {
        color: #0056b3;
    }
</style>

<?= $this->endSection() ?>
