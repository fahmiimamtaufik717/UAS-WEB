<?= $this->extend('user/layouts/template') ?>

<?= $this->section('content') ?>
<div class="d-flex">
    <!-- Sidebar -->
    <div class="side-bar bg-dark text-white vh-100 p-3">
        <div class="text-center mb-4">
            <img src="/assets/img/ci4/icn.png" alt="Klinik Merdeka" class="img-fluid" style="max-width: 100px;">
        </div>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/user/dashboard" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/user/agenda" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-database me-2"></i> Data Antrian
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="/auth/logout" class="nav-link btn btn-primary text-white">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="container-xl mt-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Daftar Antrian</h3>
                    </div>

                    <!-- Tombol Tambah Data dan Search -->
                    <div class="card-body border-bottom py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <!-- Tombol Tambah Data -->
                            <a href="/user/create" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i> Tambah Data
                            </a>
                            <!-- Fitur Search -->
                            <div class="d-flex text-secondary">
                                Search:
                                <div class="ms-2 d-inline-block">
                                    <form method="get" action="/user/agenda">
                                        <input type="text" name="search" class="form-control form-control-sm" value="<?= isset($search) ? esc($search) : '' ?>" aria-label="Search invoice">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tabel Daftar Antrian -->
                    <div class="card-body">
                        <table class="table table-vcenter table-bordered">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Nama Pasien</th>
                                    <th>Jenis Pelayanan</th>
                                    <th>Tanggal Kunjungan</th>
                                    <th>Jam Kunjungan</th>
                                    <th>Ruangan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = (int) (isset($pager) ? $pager->getPerPage() * ($pager->getCurrentPage() - 1) : 0); ?>
                                <?php foreach ($agenda as $a): ?>
                                    <tr>
                                        <td class="text-center"><?= ++$no ?></td>
                                        <td><?= esc($a['nama_pasien']) ?></td>
                                        <td><?= esc($a['jenis_pelayanan']) ?></td>
                                        <td><?= esc($a['tanggal_kunjungan']) ?></td>
                                        <td><?= esc($a['jam_kunjungan']) ?></td>
                                        <td><?= esc($a['ruangan']) ?></td>
                                        <td class="text-center">
                                            <?php if (strtolower($a['status']) == 'pending'): ?>
                                                <span class="badge bg-warning text-dark"><?= esc($a['status']) ?></span>
                                            <?php elseif (strtolower($a['status']) == 'approved'): ?>
                                                <span class="badge bg-success text-white"><?= esc($a['status']) ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-danger text-white"><?= esc($a['status']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="card-footer d-flex align-items-center">
                        <p class="m-0 text-secondary">Showing <?= $pager->getCurrentPage() ?> of <?= $pager->getPageCount() ?> entries</p>
                        <ul class="pagination m-0 ms-auto">
                            <?= $pager->links() ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
